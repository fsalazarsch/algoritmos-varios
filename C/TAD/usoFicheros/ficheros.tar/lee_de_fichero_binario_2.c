/*
  Lectura de un archivo binario.

  Este programa lee n�meros del fichero "NUMEROS.DAT" y los escribe por la
  pantalla. Igual que el ejercicio anterior pero mejorado.


*/


# include <stdio.h>

void main(void)
{
   FILE *fich;   /* puntero del fichero */
   int n;        /* n�mero a leer */

   printf("Lectura del archivo NUMEROS.DAT: \n");
   if ((fich=fopen("NUMEROS.DAT","rb"))==NULL)
   {
      printf("Error al abrir el fichero.\n");
      exit(1);
   }
   while (fread(&n,sizeof(int),1,fich))  /* fread>0 si ha le�do registros */
      printf("%d\n",n);
   fclose(fich);
}

