/* Lectura de un fichero texto.

Este programa lee las frases que hay en un fichero de texto introducido como argumento 
al llamar al programa y lo escribe por la pantalla
*/

# include <stdio.h>
# include <string.h>

# define MAX_LONGITUD 256  /* supondremos que la m�xima longitud de una l�nea es 255 */

void main(int argc, char *argv[])
{
   FILE *texto; 
   char linea[MAX_LONGITUD];        

/* si no hay por lo menos un argumento acabamos */

   if (argc<2)
   {
      printf("No ha introducido nombre de fichero.\n");
      exit(1);
   }

/* abrimos el archivo para lectura */

   if ((texto=fopen(argv[1],"rt"))==NULL)
   {
      printf("No es posible abrir para lectura el fichero %s\n",argv[1]);
      exit(1);
   }

/* proceso */

   fgets(linea,MAX_LONGITUD,texto);  /* leo del fichero */
   while (!feof(texto))
   {
      printf("%s",linea);
      fgets(linea,MAX_LONGITUD,texto);  /* leo del fichero */
   }
   fclose(texto);
}

