/* Ejemplo escritura en un fichero binario.

  Este programa lee n�meros del teclado y los introduce en un archivo llamado
  "NUMEROS.DAT" (Ser� binario). Terminamos cuando introduzcamos un cero.
*/

# include <stdio.h>

void main(void)
{
   FILE *fich;   /* puntero del fichero */
   int n;        /* n�mero a escribir */

   printf("Introduzca los n�meros del archivo: \n");
   fich = fopen("NUMEROS.DAT","wb");   /* abrimos el archivo para escritura */
   scanf("%d",&n);
   while (n)
   {
      fwrite(&n,sizeof(int),1,fich);  /* escribo en el fichero */
      scanf("%d",&n);
   }
   fclose(fich);
}
