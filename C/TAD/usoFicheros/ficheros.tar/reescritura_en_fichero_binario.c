/* Tengo un archivo llamado "NUMEROS.DAT" compuesto por registros con tres campos: 

	n entero
	m entero
	c real

queremos cambiar el contenido de estos registros de esta forma, cuando n sea menor que m haremos 
que el campo c valga cero, y en caso contrario (n>=m) haremos que el campo c sea el n�mero 
combinatorio de n sobre m.

ALGORITMO Reescritura
TIPOS
   reg_datos = REGISTRO
	       	   n,m: ENTERO;
	       	   c: REAL;
               FIN-REGISTRO;

ENTORNO
   reg: reg_datos;
   fich: FICHERO DE datos;

INICIO
   ASIGNAR "DATOS.DAT" A fich;
   ABRIR fich PARA L/E;
   MIENTRAS NO EOF(fich) HACER
	 LEER reg DE fich;
	 SI reg.n < reg.m
	    ENTONCES reg.c <-- 0;
	    SINO reg.c <-- Fac(reg.n)/(Fac(reg.m)*Fac(reg.n-reg.m));
	 FINSI;
	 Reescribe(fich,reg);  //Construimos este procedimiento
   FIN-MIENTRAS;
   CERRAR fich;
FIN

PROC Reescribe(fich: FICHERO DE reg_datos, reg: reg_datos)
INICIO
   POSICIONA(fich,NUM_REG(fich)-1); //retrasamos una posici�n
   ESCRIBE reg EN fich;
FIN

*/

# include <stdio.h>

struct reg_datos 
   {
	int n,m;
	float c;
   };

long int Fac(int n);
void Reescribe(FILE *fich, struct reg_datos *reg);

void main(void)
{
   struct reg_datos reg;
   FILE *fich;

/* abrimos fich para lectura/escritura */

   if ((fich=fopen("NUMEROS.DAT","rb+"))==NULL)
   {
      printf("Error al abrir el fichero.\n");
      exit(1);
   }

/* proceso */

   while (fread(&reg,sizeof(struct reg_datos),1,fich))
   {
      if (reg.n < reg.m)
	 reg.c = 0;
      else
         reg.c = (float) Fac(reg.n)/(Fac(reg.m)*Fac(reg.n-reg.m));
      Reescribe(fich,&reg);
   }
   fclose(fich);
}

long int Fac(int n)
{
   long int f=1;
   int i;

   for (i=n;i>1;i--)
      f *= i;
   return f;
}


void Reescribe(FILE *fich, struct reg_datos *reg)
{
   long int byte_actual = ftell(fich);   

/* lo primero que tenemos que hacer es posicionar el puntero un registro atr�s */

   fseek(fich, byte_actual-sizeof(struct reg_datos), SEEK_SET);
 
/* ahora "reescribimos" nuestro registro en la posici�n correcta */

   fwrite(reg,sizeof(struct reg_datos),1,fich);
   fflush(fich);
}
