/*
  Lectura de un fichero binario.

  Este programa lee n�meros del fichero "NUMEROS.DAT" y los escribe por la
  pantalla.
*/

# include <stdio.h>

void main(void)
{
   FILE *fich;   /* puntero del fichero */
   int n;        /* n�mero a leer */

   printf("Lectura del archivo NUMEROS.DAT: \n");
   fich = fopen("NUMEROS.DAT","rb");   /* abrimos el archivo para lectura */
   fread(&n,sizeof(int),1,fich);  /* leo del fichero */
   while (!feof(fich))
   {
      printf("%d\n",n);
      fread(&n,sizeof(int),1,fich);  /* leo del fichero */
   }
   fclose(fich);
}

