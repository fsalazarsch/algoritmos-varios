#include <stdio.h>
#include <malloc.h>

#define TAM 10

int main(void)
{
   int *vector,i;
   
/* asignamos al puntero el resultado de la funci�n malloc()
   haci�ndole el casting correspondiente (el prototipo de malloc
   es void *malloc (size_t size) */
   
   vector = (int *) malloc(sizeof(int)*TAM);
   
/* damos valor a los 10 enteros a los que apunta el puntero, y a 
   �ste lo tratamos como un vector */
   
   for (i=0; i<TAM; i++)
      vector[i]=i+1;

/* escribimos estos valores */
   
   for (i=0; i<TAM; i++)
      printf("%d\n",vector[i]);

/* liberamos la memoria ocupada por el puntero */
      
   free(vector);
}
