/* Este programa pide un n�mero al usuario y los busca dentro del fichero
   NUMEROS.TXT.

   Escribe por pantalla si est� o no, y en caso de que est� la l�nea en
   la que est�. */

#include <stdio.h>

#define LONGITUD 11  /* longitud de la cadena + '\0' */

void lee_cadena_fichero(char *cadena,int max_longitud,FILE *fichero);

void main(void)
{
   char a_buscar[LONGITUD];  /* cadena a buscar en el fichero */
   char cadena[LONGITUD];    /* cadena le�da del fichero      */
   int n=1;                  /* n�mero de l�nea del archivo   */
   FILE *fichero;

   /* comprobamos si existe el fichero */

   if ((fichero=fopen("NUMEROS.TXT","rt"))==NULL)
   {
      printf("Error al abrir el fichero NUMEROS.TXT\n");
      exit(1);
   }

   /* pedimos al usuario la cadena a buscar en el fichero */

   printf("Cadena a buscar: ");
   gets(a_buscar);

   /* buscamos en el fichero */

   lee_cadena_fichero(cadena,LONGITUD,fichero); /* sustituimos por fgets */
   while (!feof(fichero) && strcmp(a_buscar,cadena)!=0)
   {
      /* comprobamos si hemos le�do el final del archivo o si lo que
         hemos le�do es el valor que estamos buscando. */

      n++ ;  /* una l�nea m�s, si estamos aqu� es porque el �ltimo
                registro le�do no es el que buscamos */
      lee_cadena_fichero(cadena,LONGITUD,fichero);
   }

   /* ahora comprobamos si hemos salido del bucle porque hemos encontrado
      lo que busc�bamos o porque se ha terminado el fichero */

   if (feof(fichero))
      printf("Valor no encontrado.\n");
   else
      printf("El valor buscado est� en la l�nea %d.\n",n);

   /* terminamos */

   fclose(fichero);
}

/* la siguiente funci�n opera de forma parecida a fgets, pero a diferencia
   de fgets que mete el car�cter \n al final de la cadena, esta funci�n no
   lo hace (como lo har�a fscanf). */

void lee_cadena_fichero(char *cadena,int max_longitud,FILE *fichero)
{
   int longitud_cadena;

   /* leemos la cadena */

   fgets(cadena,max_longitud,fichero);

   /* quitamos el '\n' del final de la cadena */

   longitud_cadena = strlen(cadena);
   cadena[longitud_cadena - 1] = '\0'; /* finalizador de cadena */
}

