/* Ejemplo escritura en un fichero binario.

  Este programa lee n�meros del teclado de tres en tres (dos enteros y un real) y los introduce
  como registros en un archivo llamado "NUMEROS.DAT" (Ser� binario). 

  Terminamos cuando los tres sean cero.
*/

# include <stdio.h>

struct reg_num
{
   int n,m;
   float c;
};

void LeerNum(struct reg_num *reg);

void main(void)
{
   FILE *fich;               /* puntero del fichero */
   struct reg_num numeros;   /* n�meros a escribir */

   fich = fopen("NUMEROS.DAT","wb");   /* abrimos el archivo para escritura */
   LeerNum(&numeros);
   while (numeros.n!=0 || numeros.m!=0 || numeros.c!=0)
   {
      fwrite(&numeros,sizeof(struct reg_num),1,fich);  /* escribo en el fichero */
      LeerNum(&numeros);
   }
   fclose(fich);
}

void LeerNum(struct reg_num *reg)
{
   static int n=0;

   system("clear");
   printf("Datos del registro %d:\n\n",++n);
   printf("n: ");
   scanf("%d",&reg->n);
   printf("m: ");
   scanf("%d",&reg->m);
   printf("c: ");
   scanf("%f",&reg->c);
}
