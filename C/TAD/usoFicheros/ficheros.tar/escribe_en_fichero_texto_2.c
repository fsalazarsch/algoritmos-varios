/* Ejemplo escritura en un fichero texto.

Este programa lee frases del teclado y los a�ade en el archivo que se indique como argumento 
al llamar al programa (Ser� texto). Terminamos cuando introduzcamos una cadena vac�a.

Observar como cuando el fichero existe la informaci�n se pone al final de la que ya hab�a.*/

# include <stdio.h>
# include <string.h>

void main(int argc, char *argv[])
{
   FILE *texto;   
   char frase[256];           /* frase a leer */

/* si no hay por lo menos un argumento acabamos */
   if (argc<2)
   {
      printf("No ha introducido nombre de fichero.\n");
      exit(1);
   }

/* abrimos el archivo para a�adir */
   texto=fopen(argv[1],"at");

/* proceso */
 
   gets(frase);
   while (strlen(frase))
   {
      fputs(frase,texto);  /* escribo en el fichero */
      fputs("\n",texto);
      gets(frase);
   }
   fclose(texto);
}

