/*
  Informe por pantalla de un archivo binario.

  Este programa lee registros de tres n�meros (dos enteros y un real) del fichero "NUMEROS.DAT" 
  y los muestra por pantalla de forma paginada.
*/

# include <stdio.h>

# define NUM_LIN 15

void main(void)
{
   FILE *fich;   /* puntero del fichero */
   struct reg_num 
   {
      int n,m;
      float c;
   } numeros;
   int i,fila=1,pag=1;   /* necesarias para el informe por pantalla */

   if ((fich = fopen("NUMEROS.DAT","rb"))==NULL)  /* hay error */
   {
      printf("Error al abrir el archivo.\n"); exit(1);
   }
   
   /* proceso */
   
   while (fread(&numeros,sizeof(struct reg_num),1,fich))
   {
      if (fila==1)     /* Cabecera (1� l�nea) */
      {
         system("clear");
         printf("INFORME POR PANTALLA. Pantalla %d\n\n",pag);
         printf("  n     m       c\n");
         printf("----- ----- ---------\n");
         fila=4;
      }
      /* cuerpo */
      printf("%5d %5d %9.2f\n",numeros.n,numeros.m,numeros.c);
      fila++;
      if (fila>=NUM_LIN-2)   /* Pie */
      {
         printf("\n\nPulse una tecla para continuar..."); getchar();
         pag++; 
         fila = 1;
      }
   }
   fclose(fich);
}
   

