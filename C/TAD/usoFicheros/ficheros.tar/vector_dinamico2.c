#include <stdio.h>
#include <malloc.h>

/* igual que el caso anterior pero usando aritm�tica de punteros */

#define TAM 10

void reserva(int **vector, int n);

int main(void)
{
   int *vector,i;
   
/* reservamos memoria pasando el puntero por referencia */
   
   reserva(&vector,TAM);
     
/* damos valor a los 10 enteros a los que apunta el puntero,  
   usando aritm�tica de punteros */
   
   for (i=0; i<TAM; i++)
      *(vector+i)=i+1;

/* escribimos estos valores */
   
   for (i=0; i<TAM; i++)
      printf("%d\n",vector[i]);

/* liberamos la memoria ocupada por el puntero */
      
   free(vector);
}

void reserva(int **vector, int n)
{
   *vector = (int *) malloc(sizeof(int)*n);
}
