/* Borrado de un registro en fichero binario (se hace igual en uno de texto).

   Este programa borra un registro del fichero "NUMEROS.DAT" (el que corresponda al n�mero
   que se le pase como argumento) de la siguiente forma:

  	1. Creando un fichero temporal que tenga todos los registros del fichero anterior 
           menos el que hay que borrar.

	2. Borrando el primer fichero (NUMEROS.DAT).

	3. Renombrando el fichero temporal. */

# include <stdio.h>

void main(int argc, char *argv[])
{
   int n,borrame; /* registro de transferencia y n�mero a borrar */
   FILE *fich,*temporal; 
   
/* primero comprobamos que el n�mero de argumentos es correcto */

   if (argc<2)    /* no hay argumento, terminamos. */
   {
      printf("No ha introducido el n�mero a borrar.\n");
      exit(1);
   }
   
/* abrimos el fichero */

   if ((fich = fopen("NUMEROS.DAT","rb"))==NULL)   /* abrimos el archivo para lectura */
   {
      printf("No existe el fichero.\n");
      exit(1);
   }
   
/* proceso */

   temporal = fopen("temporal","wb");   /* creamos fichero temporal */
   
   borrame=atoi(argv[1]);
   while (fread(&n,sizeof(int),1,fich)) /* copiamos registros en temporal */
      if (n!=borrame)                   /* s�lo si no es el que hay que borrar */
         fwrite(&n,sizeof(int),1,temporal);
   
   fclose(fich);                        /* cerramos ficheros */
   fclose(temporal);
   
   remove("NUMEROS.DAT");               /* borramos y renombramos */
   rename("temporal","NUMEROS.DAT");
}

